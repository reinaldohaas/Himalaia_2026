#!/bin/bash
# Devolve os resultados do vlab via GitHub Release (nao entra no historico do git).
#
# Uso:  bash devolver_github.sh            # sobe o pacote LEVE mais recente (figuras, JSON, estatisticas, logs)
#       bash devolver_github.sh --completo # sobe tambem o pacote completo, dividido em partes de 1,9 GB
#
# Requisitos:
#   - gh (GitHub CLI). Se nao houver, e instalado no ambiente conda "cm1pos".
#   - login feito por VOCE, uma vez, no terminal do Jupyter:   gh auth login
#     (escolha GitHub.com > HTTPS > "Login with a web browser" e cole o codigo em github.com/login/device)
#     Este script nunca le, grava nem imprime token.
#   - ATENCAO: o repositorio e publico, entao o Release tambem e publico.
set -euo pipefail
AQUI=$(cd "$(dirname "$0")" && pwd)
source "$AQUI/ambiente.sh"
REPO=${REPO:-reinaldohaas/Himalaia_2026}
COMPLETO=0; [ "${1:-}" = "--completo" ] && COMPLETO=1

if ! command -v gh >/dev/null 2>&1; then
  usar_env cm1pos python=3.11 numpy matplotlib gh
  garantir cm1pos gh gh
fi
gh auth status >/dev/null 2>&1 || { echo "Faca o login primeiro:  gh auth login   (e rode este script de novo)" >&2; exit 1; }

LEVE=$(ls -t "$AQUI"/resultados_cm1_leve_*.tar.gz 2>/dev/null | head -1 || true)
[ -n "$LEVE" ] || { echo "Nenhum pacote leve. Rode antes: bash pos/analisar.sh && bash coletar.sh --leve" >&2; exit 1; }
ARQS=("$LEVE" "$LEVE.sha256")

if [ $COMPLETO = 1 ]; then
  CHEIO=$(ls -t "$AQUI"/resultados_cm1_2*.tar.gz 2>/dev/null | head -1 || true)
  [ -n "$CHEIO" ] || { echo "Nenhum pacote completo. Rode antes: bash coletar.sh" >&2; exit 1; }
  split -b 1900M -d -a 2 "$CHEIO" "$CHEIO.parte"
  for p in "$CHEIO".parte*; do ARQS+=("$p"); done
  ARQS+=("$CHEIO.sha256")
fi

TAG=cm1-vlab-$(date +%Y%m%d-%H%M)
NOTAS="Saidas do toro-CM1 (Lhende Khola 2026) rodadas no vlab/UFSC.
Pacote: cluster/toro_cm1_lhende_vlab.tar.gz. Execucoes: $(ls "$AQUI/execucoes" 2>/dev/null | tr '\n' ' ')
Partes do pacote completo: juntar com  cat resultados_cm1_*.tar.gz.parte* > resultados.tar.gz  e conferir com sha256sum -c."
gh release create "$TAG" --repo "$REPO" --prerelease --title "$TAG" --notes "$NOTAS" "${ARQS[@]}"
echo "OK: https://github.com/$REPO/releases/tag/$TAG"
echo "No seu computador:  gh release download $TAG --repo $REPO"
