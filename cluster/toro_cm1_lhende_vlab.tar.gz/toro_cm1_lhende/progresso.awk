# usado por rodar_direto.sh estado: linha de progresso de uma execucao
BEGIN {
  pct = 100 * mt / tm
  printf "      modelo: %.0f s de %.0f (%.1f%%) = %.2f h de %.2f h", mt, tm, pct, mt / 3600, tm / 3600
  if (dt > 0) {
    r = mt / dt
    printf "  | relogio %.2f h | ritmo %.2f s modelo/s", dt / 3600, r
    if (fim == 0 && r > 0) printf " | faltam ~%.1f h no ritmo medio ate agora", (tm - mt) / r / 3600
  }
  print ""
}
