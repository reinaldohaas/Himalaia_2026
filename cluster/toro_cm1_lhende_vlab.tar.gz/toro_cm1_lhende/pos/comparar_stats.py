# -*- coding: utf-8 -*-
"""
Compara duas rodadas do CM1 pelo cm1out_stats (1 registro por minuto de modelo).

  python comparar_stats.py <dir_A> <dir_B>

Diz se os arquivos sao identicos byte a byte; senao, o primeiro instante em que cada variavel
difere (qualquer bit) e o primeiro em que difere mais de 0,1 % do maximo da serie.
"""
import os
import sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import grads

A, B = sys.argv[1], sys.argv[2]
fa, fb = os.path.join(A, "cm1out_stats.dat"), os.path.join(B, "cm1out_stats.dat")
ba, bb = open(fa, "rb").read(), open(fb, "rb").read()
n = min(len(ba), len(bb))
print("A: %s (%d bytes)\nB: %s (%d bytes)" % (A, len(ba), B, len(bb)))
if ba[:n] == bb[:n]:
    print("IDENTICOS byte a byte nos primeiros %d bytes (trecho comum)." % n)
    sys.exit(0)
sa, _ = grads.stats(os.path.join(A, "cm1out_stats.ctl"))
sb, _ = grads.stats(os.path.join(B, "cm1out_stats.ctl"))
m = min(len(sa["mtime"]), len(sb["mtime"]))
t = sa["mtime"][:m]
print("registros comparados: %d (0 a %.2f h de modelo)" % (m, t[-1] / 3600))
prim = []
for k in sa:
    if k not in sb:
        continue
    a, b = sa[k][:m], sb[k][:m]
    dif = a != b
    if not dif.any():
        continue
    i0 = np.argmax(dif)
    esc = np.nanmax(np.abs(a)) or 1.0
    rel = np.abs(a - b) / esc
    i1 = np.argmax(rel > 1e-3) if (rel > 1e-3).any() else None
    prim.append((t[i0], k, i1))
    print("  %-9s 1o bit diferente: %7.0f s (%.2f h) | >0,1%%: %s | dif max %.2e" % (
        k, t[i0], t[i0] / 3600, "nunca" if i1 is None else "%.2f h" % (t[i1] / 3600), np.nanmax(rel)))
if prim:
    prim.sort()
    print("PRIMEIRA divergencia: %s em %.0f s de modelo" % (prim[0][1], prim[0][0]))
