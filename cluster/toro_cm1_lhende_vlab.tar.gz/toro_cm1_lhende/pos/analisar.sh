#!/bin/bash
# Pos-processamento: liga as execucoes nesta pasta e gera tabelas, JSON e figuras.
# Uso:  bash pos/analisar.sh [DIR_EXECUCOES]   (padrao: ../execucoes)
# Precisa de python3 com numpy e matplotlib; se nao houver, cria o ambiente conda $ENVDIR/cm1pos (ver ambiente.sh).
set -euo pipefail
POS=$(cd "$(dirname "$0")" && pwd)
EXEC=$(cd "${1:-$POS/../execucoes}" && pwd)
cd "$POS"

PY=${PY:-python3}
if ! $PY -c "import numpy, matplotlib" >/dev/null 2>&1; then
  source "$POS/../ambiente.sh"
  usar_env cm1pos python=3.11 numpy matplotlib; PY=python
fi
export MPLBACKEND=Agg

for d in "$EXEC"/*/; do d=${d%/}; n=$(basename "$d"); [ -e "$n" ] || ln -s "$d" "$n"; done
ls -d run_* >/dev/null 2>&1 && { $PY analisar_cm1.py; $PY figura_cm1.py "$POS/toro_cm1_plano.png"; } || echo "(sem rodadas planas)"
ls -d ter_* >/dev/null 2>&1 && { $PY analisar_terreno.py; $PY figura_terreno.py "$POS/toro_cm1_terreno.png"; } || echo "(sem rodadas de terreno)"
ls -d rad_* >/dev/null 2>&1 && { $PY analisar_rad.py; $PY figura_rad.py "$POS/toro_cm1_radiacao.png"; } || echo "(sem rodadas com radiacao)"
ls -l "$POS"/*.png "$POS"/*.json 2>/dev/null || true
