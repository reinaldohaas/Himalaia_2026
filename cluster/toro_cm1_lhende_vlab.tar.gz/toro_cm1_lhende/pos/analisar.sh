#!/bin/bash
# Pos-processamento: liga as execucoes nesta pasta e gera tabelas, JSON e figuras.
# Uso:  bash pos/analisar.sh [DIR_EXECUCOES]   (padrao: ../execucoes)
# Requer python3 com numpy e matplotlib.
set -euo pipefail
POS=$(cd "$(dirname "$0")" && pwd)
EXEC=$(cd "${1:-$POS/../execucoes}" && pwd)
cd "$POS"
for d in "$EXEC"/*/; do d=${d%/}; n=$(basename "$d"); [ -e "$n" ] || ln -s "$d" "$n"; done
PY=${PY:-python3}
ls -d run_* >/dev/null 2>&1 && { $PY analisar_cm1.py; $PY figura_cm1.py "$POS/toro_cm1_plano.png"; } || echo "(sem rodadas planas)"
ls -d ter_* >/dev/null 2>&1 && { $PY analisar_terreno.py; $PY figura_terreno.py "$POS/toro_cm1_terreno.png"; } || echo "(sem rodadas de terreno)"
ls -d rad_* >/dev/null 2>&1 && { $PY analisar_rad.py; $PY figura_rad.py "$POS/toro_cm1_radiacao.png"; } || echo "(sem rodadas com radiacao)"
ls -l "$POS"/*.png "$POS"/*.json 2>/dev/null
