#!/bin/bash
# Compila o CM1 r21.1 deste pacote (ja com a opcao initsfc=5) com gfortran + OpenMP.
# Uso:  bash compilar.sh            (no no de login ou num job interativo)
#       NPROC=16 bash compilar.sh
set -euo pipefail
AQUI=$(cd "$(dirname "$0")" && pwd)
source "$AQUI/ambiente.sh"
cd "$AQUI/cm1/src"
rm -f ../run/cm1.env

# 1) gfortran do sistema ou de um modulo
if ! command -v gfortran >/dev/null 2>&1; then
  if [ -n "${MODULESHOME:-}" ] || type module >/dev/null 2>&1; then
    for m in gcc gnu GCC gnu13 gnu12 gnu11; do
      if module load "$m" >/dev/null 2>&1; then echo "modulo carregado: $m"; break; fi
    done
  fi
fi

# 2) recuo: ambiente conda-forge persistente $ENVDIR/cm1 (fora de /root)
if ! command -v gfortran >/dev/null 2>&1; then
  usar_env cm1 gfortran gcc make
  echo "ENV_PREFIX=$ENVDIR/cm1" > ../run/cm1.env      # rodar_caso.sh usa as bibliotecas daqui
fi

command -v cpp >/dev/null 2>&1 || { echo "ERRO: 'cpp' (pre-processador C) nao encontrado" >&2; exit 1; }
echo "compilador: $(gfortran --version | head -1)"
mkdir -p ../run
make clean >/dev/null 2>&1 || true
make -j"${NPROC:-8}" FC=gfortran USE_OPENMP=true > ../compilacao.log 2>&1 || {
  echo "ERRO na compilacao; ultimas linhas de cm1/compilacao.log:" >&2; tail -30 ../compilacao.log >&2; exit 1; }
test -x ../run/cm1.exe
grep -q fopenmp ../compilacao.log && echo "OpenMP: sim" || echo "AVISO: -fopenmp nao aparece no log"
sha256sum ../run/cm1.exe | tee ../run/cm1.exe.sha256
if [ -f ../run/cm1.env ]; then source ../run/cm1.env; export LD_LIBRARY_PATH="$ENV_PREFIX/lib:${LD_LIBRARY_PATH:-}"; fi
if ldd ../run/cm1.exe | grep -q "not found"; then echo "AVISO: bibliotecas faltando:" >&2; ldd ../run/cm1.exe | grep "not found" >&2; fi
echo "OK: $AQUI/cm1/run/cm1.exe   (base persistente: $PERSIST)"
