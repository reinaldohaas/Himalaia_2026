#!/bin/bash
# Compila o CM1 r21.1 deste pacote (ja com a opcao initsfc=5) com gfortran + OpenMP.
# Uso:  bash compilar.sh            (no no de login ou num job interativo)
#       NPROC=16 bash compilar.sh
set -euo pipefail
AQUI=$(cd "$(dirname "$0")" && pwd)
cd "$AQUI/cm1/src"

# 1) gfortran do sistema ou de um modulo
if ! command -v gfortran >/dev/null 2>&1; then
  if [ -n "${MODULESHOME:-}" ] || type module >/dev/null 2>&1; then
    for m in gcc gnu GCC gnu13 gnu12 gnu11; do
      if module load "$m" >/dev/null 2>&1; then echo "modulo carregado: $m"; break; fi
    done
  fi
fi

# 2) recuo: ambiente conda-forge "cm1" na $HOME (mesmo esquema do videoaula_vlab)
if ! command -v gfortran >/dev/null 2>&1; then
  export PATH=$HOME/miniforge3/bin:$PATH
  MAMBA=$(command -v mamba || command -v conda || true)
  if [ -z "$MAMBA" ]; then
    echo "ERRO: sem gfortran, sem modulo gcc e sem conda/mamba. Instale o Miniforge (ver README)." >&2
    exit 1
  fi
  if ! $MAMBA env list | grep -q '^cm1 '; then
    $MAMBA create -y -n cm1 -c conda-forge gfortran gcc make
  fi
  source "$(dirname "$MAMBA")/../etc/profile.d/conda.sh"
  conda activate cm1
fi

command -v cpp >/dev/null 2>&1 || { echo "ERRO: 'cpp' (pre-processador C) nao encontrado" >&2; exit 1; }
echo "compilador: $(gfortran --version | head -1)"
mkdir -p ../run
make clean >/dev/null 2>&1 || true
make -j"${NPROC:-8}" FC=gfortran USE_OPENMP=true > ../compilacao.log 2>&1 || {
  echo "ERRO na compilacao; ultimas linhas de cm1/compilacao.log:" >&2; tail -30 ../compilacao.log >&2; exit 1; }
test -x ../run/cm1.exe
grep -q fopenmp ../compilacao.log && echo "OpenMP: sim" || echo "AVISO: -fopenmp nao aparece no log"
sha256sum ../run/cm1.exe | tee ../run/cm1.exe.sha256
echo "OK: $AQUI/cm1/run/cm1.exe"
