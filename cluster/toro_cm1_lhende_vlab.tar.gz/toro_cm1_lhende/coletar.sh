#!/bin/bash
# Empacota as saidas das execucoes concluidas.
# Uso:  bash coletar.sh [--leve] [caso ...]   (sem casos: todos os que terminaram normalmente)
#   --leve : so figuras/JSON do pos/, estatisticas (cm1out_stats), logs e namelists -> poucos MB,
#            para baixar pelo navegador do Jupyter (botao direito > Download).
#            Rode antes:  bash pos/analisar.sh
#   (sem --leve): tudo (GrADS 3D) -> ~11 GB; fica no cluster.
#       EXEC=/scratch/$USER/cm1 bash coletar.sh --leve
set -euo pipefail
AQUI=$(cd "$(dirname "$0")" && pwd)
EXEC=${EXEC:-$AQUI/execucoes}
LEVE=0; [ "${1:-}" = "--leve" ] && { LEVE=1; shift; }
cd "$EXEC"
if [ $# -ge 1 ]; then CASOS=("$@"); else
  mapfile -t CASOS < <(for d in */; do d=${d%/}; grep -qs "Program terminated normally" "$d/cm1.print.out" && echo "$d"; done)
fi
[ ${#CASOS[@]} -ge 1 ] || { echo "nenhuma execucao concluida em $EXEC"; exit 1; }
LISTA=$(mktemp)
for c in "${CASOS[@]}"; do
  if [ $LEVE = 1 ]; then
    for f in "$c"/cm1out_stats.ctl "$c"/cm1out_stats.dat "$c"/namelist.input "$c"/input_sounding "$c"/execucao.info "$c"/cm1.print.out; do
      [ -f "$f" ] && echo "$EXEC/$f"; done
  else
    for f in "$c"/cm1out_*.ctl "$c"/cm1out_*.dat "$c"/namelist.input "$c"/input_sounding "$c"/execucao.info "$c"/cm1.print.out \
             "$c"/perts.dat "$c"/sfc_init.dat; do [ -f "$f" ] && echo "$EXEC/$f"; done
  fi
done > "$LISTA"
if [ $LEVE = 1 ]; then
  for f in "$AQUI"/pos/*.png "$AQUI"/pos/*.json; do [ -f "$f" ] && echo "$f"; done >> "$LISTA"
  SAIDA="$AQUI/resultados_cm1_leve_$(date +%Y%m%d_%H%M).tar.gz"
else
  SAIDA="$AQUI/resultados_cm1_$(date +%Y%m%d_%H%M).tar.gz"
fi
tar -czf "$SAIDA" -P -T "$LISTA" --transform "s|^$EXEC/|execucoes/|" --transform "s|^$AQUI/pos/|pos/|"
rm -f "$LISTA"
sha256sum "$SAIDA" | tee "$SAIDA.sha256"
du -h "$SAIDA"
if [ $LEVE = 1 ]; then
  echo "baixar pelo Jupyter: no painel de arquivos, abra $(dirname "$SAIDA"), botao direito em $(basename "$SAIDA") > Download"
else
  echo "pacote completo gerado no cluster (grande demais para o navegador)."
fi
