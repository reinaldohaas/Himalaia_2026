#!/bin/bash
# Empacota as saidas das execucoes concluidas para trazer de volta.
# Uso:  bash coletar.sh [caso ...]      (sem argumentos: todos os que terminaram normalmente)
#       EXEC=/scratch/$USER/cm1 bash coletar.sh
set -euo pipefail
AQUI=$(cd "$(dirname "$0")" && pwd)
EXEC=${EXEC:-$AQUI/execucoes}
cd "$EXEC"
if [ $# -ge 1 ]; then CASOS=("$@"); else
  mapfile -t CASOS < <(for d in */; do d=${d%/}; grep -qs "Program terminated normally" "$d/cm1.print.out" && echo "$d"; done)
fi
[ ${#CASOS[@]} -ge 1 ] || { echo "nenhuma execucao concluida em $EXEC"; exit 1; }
SAIDA="$AQUI/resultados_cm1_$(date +%Y%m%d_%H%M).tar.gz"
tar -czf "$SAIDA" \
  $(for c in "${CASOS[@]}"; do echo "$c/cm1out_*.ctl $c/cm1out_*.dat $c/namelist.input $c/input_sounding $c/execucao.info $c/cm1.print.out"; \
    for f in perts.dat sfc_init.dat; do [ -f "$c/$f" ] && echo "$c/$f"; done; done)
sha256sum "$SAIDA" | tee "$SAIDA.sha256"
du -h "$SAIDA"
echo "trazer:  rsync -avP vlab:$SAIDA ./"
