#!/bin/bash
# Submete casos do CM1 ao Slurm, um job por caso (cpus/tempo/memoria de casos.txt).
#
# Uso:  bash submeter.sh [opcoes] <selecao>
#   selecao : nome(s) de caso, ou grupo: plano | terreno | rad | todos
#   -p PART : particao Slurm (padrao: a particao padrao do sinfo, marcada com *)
#   -A CONTA: conta/projeto Slurm, se o vlab exigir
#   -t      : teste curto (120 s de modelo) em <caso>_teste, 30 min de fila
#   -n      : so mostra os comandos sbatch, nao submete
#   -e DIR  : diretorio das execucoes (padrao: ./execucoes; use o scratch se houver)
#
# Exemplos:
#   bash submeter.sh -n todos            # ver o que seria submetido
#   bash submeter.sh -t rad_06utc        # teste de 2 min de modelo
#   bash submeter.sh rad                 # as duas rodadas com radiacao
#   bash submeter.sh -p cpu todos
set -euo pipefail
AQUI=$(cd "$(dirname "$0")" && pwd)
PART=""; CONTA=""; TESTE=0; SECO=0; EXEC="${EXEC:-$AQUI/execucoes}"
while getopts "p:A:tne:" o; do
  case $o in p) PART=$OPTARG;; A) CONTA=$OPTARG;; t) TESTE=1;; n) SECO=1;; e) EXEC=$OPTARG;; *) exit 1;; esac
done
shift $((OPTIND-1))
[ $# -ge 1 ] || { sed -n '2,19p' "$0"; exit 1; }
command -v sbatch >/dev/null 2>&1 || [ $SECO = 1 ] || { echo "ERRO: sbatch nao encontrado (esta no no de login do vlab?)" >&2; exit 1; }
[ -x "$AQUI/cm1/run/cm1.exe" ] || [ $SECO = 1 ] || { echo "ERRO: compile antes: bash compilar.sh" >&2; exit 1; }

if [ -z "$PART" ] && command -v sinfo >/dev/null 2>&1; then
  PART=$(sinfo -h -o "%P" | grep '\*' | head -1 | tr -d '*' || true)
fi
echo "particao: ${PART:-<padrao do Slurm>}   execucoes em: $EXEC"
mkdir -p "$AQUI/logs" "$EXEC"

SEL=" $* "
grep -v '^#' "$AQUI/casos.txt" | while read -r caso grupo cpus tempo mem resto; do
  [ -n "${caso:-}" ] || continue
  if [[ "$SEL" == *" todos "* || "$SEL" == *" $grupo "* || "$SEL" == *" $caso "* ]]; then
    [ $TESTE = 1 ] && tempo=00:30:00
    nome=cm1_${caso}; [ $TESTE = 1 ] && nome=${nome}_teste
    args=(--job-name="$nome" --nodes=1 --ntasks=1 --cpus-per-task="$cpus" --mem="$mem" --time="$tempo"
          --output="$AQUI/logs/${nome}-%j.out"
          --chdir="$AQUI" --export=ALL,PACOTE="$AQUI",CASO="$caso",TESTE="$TESTE",EXEC="$EXEC")
    [ -n "$PART" ] && args+=(--partition="$PART")
    [ -n "$CONTA" ] && args+=(--account="$CONTA")
    if [ $SECO = 1 ]; then
      echo "sbatch ${args[*]} $AQUI/job_cm1.sbatch"
    else
      sbatch "${args[@]}" "$AQUI/job_cm1.sbatch"
    fi
  fi
done
[ $SECO = 1 ] || echo "acompanhar:  squeue -u \$USER   |   tail -f $AQUI/logs/cm1_*.out"
